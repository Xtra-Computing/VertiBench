
#ifndef NTL_vec_vec_GF2E__H
#define NTL_vec_vec_GF2E__H

#include <NTL/vec_GF2E.h>

NTL_OPEN_NNS

typedef Vec< Vec<GF2E> > vec_vec_GF2E;

NTL_CLOSE_NNS

#endif
